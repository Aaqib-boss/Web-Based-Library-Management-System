# Library Management System

A comprehensive web-based library management system built with Spring Boot, featuring user authentication, book management, borrowing system, and fine management.

## 🚀 Features

### Core Functionality
- **User Management**: Admin and member user roles with authentication
- **Book Management**: Add, edit, delete, and search books
- **Borrowing System**: Borrow and return books with due date tracking
- **Fine Management**: Automatic fine calculation for overdue books
- **Dashboard**: Statistics and overview for both admins and members
- **Search & Filter**: Advanced book search by title, author, genre, and ISBN

### Technical Features
- **Spring Boot 3.5.6** with Java 17
- **Spring Security** for authentication and authorization
- **Spring Data JPA** with Hibernate for database operations
- **Thymeleaf** for server-side templating
- **SQL Server** database support
- **Responsive Design** with modern CSS
- **Session Management** for user state

## 🛠️ Technology Stack

- **Backend**: Spring Boot, Spring Security, Spring Data JPA
- **Frontend**: Thymeleaf, HTML5, CSS3, JavaScript
- **Database**: Microsoft SQL Server
- **Build Tool**: Maven
- **Java Version**: 17

## 📋 Prerequisites

Before running the application, ensure you have:

1. **Java 17** or higher installed
2. **Maven** (or use the included Maven wrapper)
3. **Microsoft SQL Server** (2019 or later)
4. **SQL Server Management Studio** (optional, for database management)

## 🗄️ Database Setup

### Option 1: Using SQL Server Management Studio
1. Open SQL Server Management Studio
2. Connect to your SQL Server instance
3. Open and execute the `database_setup.sql` script
4. Verify the `LibraryDB` database and tables are created

### Option 2: Using Command Line
```bash
sqlcmd -S localhost -i database_setup.sql
```

### Database Configuration
Update the database connection details in `src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:sqlserver://localhost:1433;databaseName=LibraryDB;encrypt=true;trustServerCertificate=true
spring.datasource.username=your_username
spring.datasource.password=your_password
```

## 🚀 Running the Application

### Using Maven Wrapper (Recommended)
```bash
# Navigate to the project directory
cd Library_Management

# Run the application
.\mvnw.cmd spring-boot:run
```

### Using Maven (if installed)
```bash
# Navigate to the project directory
cd Library_Management

# Clean and compile
mvn clean compile

# Run the application
mvn spring-boot:run
```

### Using IDE
1. Import the project as a Maven project
2. Run the `LibraryManagementApplication.java` class

## 🌐 Accessing the Application

Once the application starts, you can access it at:
- **URL**: http://localhost:8080
- **Admin Login**: admin / admin123
- **User Login**: user1 / user123

## 📁 Project Structure

```
Library_Management/
├── src/main/java/com/group176/SE_PROJECT/
│   ├── config/                 # Configuration classes
│   │   ├── DataInitializer.java
│   │   ├── SecurityConfig.java
│   │   └── ...
│   ├── controller/             # REST controllers
│   │   ├── AdminController.java
│   │   ├── AuthController.java
│   │   └── ...
│   ├── model/                  # Entity classes
│   │   ├── User.java
│   │   ├── Book.java
│   │   ├── BorrowRecord.java
│   │   └── Fine.java
│   ├── repository/             # Data access layer
│   │   ├── UserRepository.java
│   │   ├── BookRepository.java
│   │   └── ...
│   ├── service/                # Business logic layer
│   │   ├── UserService.java
│   │   ├── BookService.java
│   │   └── ...
│   └── LibraryManagementApplication.java
├── src/main/resources/
│   ├── templates/              # Thymeleaf templates
│   │   ├── admin/              # Admin pages
│   │   ├── member/             # Member pages
│   │   ├── auth/               # Authentication pages
│   │   └── layout.html         # Base template
│   ├── static/                 # Static resources
│   │   ├── css/                # Stylesheets
│   │   └── js/                 # JavaScript files
│   └── application.properties  # Application configuration
├── database_setup.sql          # Database setup script
└── pom.xml                     # Maven configuration
```

## 👥 User Roles

### Admin
- Manage all users (add, edit, delete)
- Manage books (add, edit, delete, view all)
- View all borrowing records
- Manage fines
- View system statistics and reports
- Access admin dashboard

### Member
- View available books
- Search and filter books
- Borrow and return books
- View personal borrowing history
- View personal fines
- Update profile information

## 🔧 Configuration

### Application Properties
Key configuration options in `application.properties`:

```properties
# Database Configuration
spring.datasource.url=jdbc:sqlserver://localhost:1433;databaseName=LibraryDB
spring.datasource.username=libraryuser
spring.datasource.password=Library@123

# JPA Configuration
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true

# Server Configuration
server.port=8080
```

### Security Configuration
- Session-based authentication
- Role-based access control
- Password-based login
- Automatic session management

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Verify SQL Server is running
   - Check database credentials in `application.properties`
   - Ensure the `LibraryDB` database exists

2. **Compilation Errors**
   - Ensure Java 17 is installed and configured
   - Run `mvn clean compile` to rebuild

3. **Port Already in Use**
   - Change the port in `application.properties`
   - Or stop the process using port 8080

4. **Login Issues**
   - Use the default credentials: admin/admin123 or user1/user123
   - Check if the database setup script was executed

### Logs
Application logs are available in the console output. Enable debug logging by adding:

```properties
logging.level.com.group176.SE_PROJECT=DEBUG
```

## 📝 API Endpoints

### Authentication
- `POST /login` - User login
- `POST /register` - User registration
- `GET /logout` - User logout

### Admin Endpoints
- `GET /admin` - Admin dashboard
- `GET /admin/users` - Manage users
- `GET /admin/books` - Manage books
- `GET /admin/borrowings` - View borrowing records
- `GET /admin/reports` - View reports

### Member Endpoints
- `GET /member` - Member dashboard
- `GET /member/books` - Browse books
- `GET /member/history` - Borrowing history
- `GET /member/profile` - User profile

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 👨‍💻 Development Team

- **Group 176** - Software Engineering Project
- **University**: [Your University Name]
- **Course**: Software Engineering

## 📞 Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Check the troubleshooting section

---

**Happy Coding! 🎉**

