-- Library Management System Database Setup Script
-- SQL Server Database Creation and Configuration

-- Create the database
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'LibraryDB')
BEGIN
    CREATE DATABASE LibraryDB;
    PRINT 'Database LibraryDB created successfully.';
END
ELSE
BEGIN
    PRINT 'Database LibraryDB already exists.';
END
GO

-- Use the LibraryDB database
USE LibraryDB;
GO

-- Create users table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[users]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[users] (
        [id] BIGINT IDENTITY(1,1) NOT NULL,
        [username] NVARCHAR(50) NOT NULL,
        [password] NVARCHAR(255) NOT NULL,
        [email] NVARCHAR(100) NOT NULL,
        [first_name] NVARCHAR(50),
        [last_name] NVARCHAR(50),
        [role] NVARCHAR(20) NOT NULL DEFAULT 'USER',
        CONSTRAINT [PK_users] PRIMARY KEY CLUSTERED ([id] ASC),
        CONSTRAINT [UQ_users_username] UNIQUE ([username]),
        CONSTRAINT [UQ_users_email] UNIQUE ([email])
    );
    PRINT 'Table users created successfully.';
END
ELSE
BEGIN
    PRINT 'Table users already exists.';
END
GO

-- Create books table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[books]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[books] (
        [id] BIGINT IDENTITY(1,1) NOT NULL,
        [title] NVARCHAR(255) NOT NULL,
        [author] NVARCHAR(255) NOT NULL,
        [isbn] NVARCHAR(20) UNIQUE,
        [publication_year] INT,
        [available_copies] INT NOT NULL DEFAULT 1,
        [total_copies] INT NOT NULL DEFAULT 1,
        [genre] NVARCHAR(100),
        [description] NVARCHAR(MAX),
        [created_date] DATETIME2 NOT NULL DEFAULT GETDATE(),
        CONSTRAINT [PK_books] PRIMARY KEY CLUSTERED ([id] ASC)
    );
    PRINT 'Table books created successfully.';
END
ELSE
BEGIN
    PRINT 'Table books already exists.';
END
GO

-- Create borrow_records table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[borrow_records]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[borrow_records] (
        [id] BIGINT IDENTITY(1,1) NOT NULL,
        [user_id] BIGINT NOT NULL,
        [book_id] BIGINT NOT NULL,
        [borrow_date] DATETIME2 NOT NULL DEFAULT GETDATE(),
        [due_date] DATETIME2 NOT NULL,
        [return_date] DATETIME2 NULL,
        [status] NVARCHAR(20) NOT NULL DEFAULT 'BORROWED',
        CONSTRAINT [PK_borrow_records] PRIMARY KEY CLUSTERED ([id] ASC),
        CONSTRAINT [FK_borrow_records_users] FOREIGN KEY ([user_id]) REFERENCES [dbo].[users] ([id]) ON DELETE CASCADE,
        CONSTRAINT [FK_borrow_records_books] FOREIGN KEY ([book_id]) REFERENCES [dbo].[books] ([id]) ON DELETE CASCADE
    );
    PRINT 'Table borrow_records created successfully.';
END
ELSE
BEGIN
    PRINT 'Table borrow_records already exists.';
END
GO

-- Create fines table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fines]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[fines] (
        [id] BIGINT IDENTITY(1,1) NOT NULL,
        [user_id] BIGINT NOT NULL,
        [amount] DECIMAL(10,2) NOT NULL,
        [reason] NVARCHAR(255),
        [is_paid] BIT NOT NULL DEFAULT 0,
        [created_date] DATETIME2 NOT NULL DEFAULT GETDATE(),
        [paid_date] DATETIME2 NULL,
        CONSTRAINT [PK_fines] PRIMARY KEY CLUSTERED ([id] ASC),
        CONSTRAINT [FK_fines_users] FOREIGN KEY ([user_id]) REFERENCES [dbo].[users] ([id]) ON DELETE CASCADE
    );
    PRINT 'Table fines created successfully.';
END
ELSE
BEGIN
    PRINT 'Table fines already exists.';
END
GO

-- Create indexes for better performance
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_books_title' AND object_id = OBJECT_ID('books'))
BEGIN
    CREATE INDEX IX_books_title ON books(title);
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_books_author' AND object_id = OBJECT_ID('books'))
BEGIN
    CREATE INDEX IX_books_author ON books(author);
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_books_isbn' AND object_id = OBJECT_ID('books'))
BEGIN
    CREATE INDEX IX_books_isbn ON books(isbn);
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_borrow_records_user_id' AND object_id = OBJECT_ID('borrow_records'))
BEGIN
    CREATE INDEX IX_borrow_records_user_id ON borrow_records(user_id);
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_borrow_records_book_id' AND object_id = OBJECT_ID('borrow_records'))
BEGIN
    CREATE INDEX IX_borrow_records_book_id ON borrow_records(book_id);
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_borrow_records_status' AND object_id = OBJECT_ID('borrow_records'))
BEGIN
    CREATE INDEX IX_borrow_records_status ON borrow_records(status);
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_fines_user_id' AND object_id = OBJECT_ID('fines'))
BEGIN
    CREATE INDEX IX_fines_user_id ON fines(user_id);
END

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_fines_is_paid' AND object_id = OBJECT_ID('fines'))
BEGIN
    CREATE INDEX IX_fines_is_paid ON fines(is_paid);
END

PRINT 'Indexes created successfully.';
GO

-- Insert sample data
-- Insert admin user
IF NOT EXISTS (SELECT 1 FROM users WHERE username = 'admin')
BEGIN
    INSERT INTO users (username, password, email, first_name, last_name, role)
    VALUES ('admin', 'admin123', 'admin@library.com', 'Admin', 'User', 'ADMIN');
    PRINT 'Admin user inserted.';
END

-- Insert regular user
IF NOT EXISTS (SELECT 1 FROM users WHERE username = 'user1')
BEGIN
    INSERT INTO users (username, password, email, first_name, last_name, role)
    VALUES ('user1', 'user123', 'user1@library.com', 'John', 'Doe', 'USER');
    PRINT 'Regular user inserted.';
END

-- Insert sample books
IF NOT EXISTS (SELECT 1 FROM books WHERE title = 'The Great Gatsby')
BEGIN
    INSERT INTO books (title, author, isbn, publication_year, available_copies, total_copies, genre, description)
    VALUES 
    ('The Great Gatsby', 'F. Scott Fitzgerald', '9780743273565', 1925, 3, 3, 'Fiction', 'A classic American novel about the Jazz Age'),
    ('To Kill a Mockingbird', 'Harper Lee', '9780061120084', 1960, 2, 2, 'Fiction', 'A story of racial injustice and childhood innocence'),
    ('1984', 'George Orwell', '9780451524935', 1949, 4, 4, 'Dystopian Fiction', 'A dystopian social science fiction novel'),
    ('Pride and Prejudice', 'Jane Austen', '9780141439518', 1813, 2, 2, 'Romance', 'A romantic novel of manners'),
    ('The Catcher in the Rye', 'J.D. Salinger', '9780316769174', 1951, 1, 1, 'Fiction', 'A coming-of-age story');
    PRINT 'Sample books inserted.';
END

PRINT 'Database setup completed successfully!';
PRINT 'Default credentials:';
PRINT 'Admin: admin / admin123';
PRINT 'User: user1 / user123';
GO

