// Books Management JavaScript

document.addEventListener('DOMContentLoaded', function() {
    initializeBookManagement();
});

function initializeBookManagement() {
    // Book search functionality
    const bookSearch = document.getElementById('bookSearch');
    if (bookSearch) {
        bookSearch.addEventListener('input', debounce(searchBooks, 300));
    }

    // Book filter functionality
    const categoryFilter = document.getElementById('categoryFilter');
    if (categoryFilter) {
        categoryFilter.addEventListener('change', filterBooksByCategory);
    }

    // Initialize book modals
    initializeBookModals();

    // Initialize bulk actions
    initializeBulkActions();
}

function searchBooks(event) {
    const searchTerm = event.target.value.toLowerCase().trim();
    const table = document.querySelector('.books-table tbody');

    if (!table) return;

    const rows = table.querySelectorAll('tr');
    let visibleCount = 0;

    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        const isVisible = text.includes(searchTerm);
        row.style.display = isVisible ? '' : 'none';

        if (isVisible) visibleCount++;
    });

    // Show/hide no results message
    const noResults = document.getElementById('noResults');
    if (noResults) {
        noResults.style.display = visibleCount === 0 ? 'block' : 'none';
    }
}

function filterBooksByCategory(event) {
    const category = event.target.value;
    const table = document.querySelector('.books-table tbody');

    if (!table) return;

    const rows = table.querySelectorAll('tr');
    let visibleCount = 0;

    rows.forEach(row => {
        const categoryCell = row.querySelector('td:nth-child(5)'); // Assuming category is 5th column
        const rowCategory = categoryCell ? categoryCell.textContent.trim() : '';
        const isVisible = !category || rowCategory === category;
        row.style.display = isVisible ? '' : 'none';

        if (isVisible) visibleCount++;
    });

    updateBookStats();
}

function initializeBookModals() {
    // Edit book modal handler
    const editModal = document.getElementById('editBookModal');
    if (editModal) {
        editModal.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            const bookId = button.getAttribute('data-book-id');
            const bookTitle = button.getAttribute('data-book-title');
            const bookAuthor = button.getAttribute('data-book-author');
            const bookIsbn = button.getAttribute('data-book-isbn');
            const bookCategory = button.getAttribute('data-book-category');
            const bookPublisher = button.getAttribute('data-book-publisher');
            const bookQuantity = button.getAttribute('data-book-quantity');

            const modal = this;
            modal.querySelector('#editId').value = bookId;
            modal.querySelector('#editTitle').value = bookTitle;
            modal.querySelector('#editAuthor').value = bookAuthor;
            modal.querySelector('#editIsbn').value = bookIsbn;
            modal.querySelector('#editCategory').value = bookCategory;
            modal.querySelector('#editPublisher').value = bookPublisher;
            modal.querySelector('#editQuantity').value = bookQuantity;
        });
    }

    // Add book form validation
    const addBookForm = document.getElementById('addBookForm');
    if (addBookForm) {
        addBookForm.addEventListener('submit', function(event) {
            if (!validateBookForm(this)) {
                event.preventDefault();
                event.stopPropagation();
            }
        });
    }

    // Edit book form validation
    const editBookForm = document.getElementById('editBookForm');
    if (editBookForm) {
        editBookForm.addEventListener('submit', function(event) {
            if (!validateBookForm(this)) {
                event.preventDefault();
                event.stopPropagation();
            }
        });
    }
}

function validateBookForm(form) {
    let isValid = true;

    // Clear previous errors
    const errorElements = form.querySelectorAll('.is-invalid');
    errorElements.forEach(element => {
        element.classList.remove('is-invalid');
    });

    const errorMessages = form.querySelectorAll('.invalid-feedback');
    errorMessages.forEach(message => message.remove());

    // Validate ISBN
    const isbn = form.querySelector('input[name="isbn"]');
    const isbnPattern = /^[0-9-]{10,17}$/;
    if (isbn && !isbnPattern.test(isbn.value)) {
        showFieldError(isbn, 'ISBN must be 10-17 digits, hyphens allowed');
        isValid = false;
    }

    // Validate quantity
    const quantity = form.querySelector('input[name="quantity"]');
    if (quantity && (quantity.value < 1 || quantity.value > 1000)) {
        showFieldError(quantity, 'Quantity must be between 1 and 1000');
        isValid = false;
    }

    // Validate required fields
    const requiredFields = form.querySelectorAll('[required]');
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            showFieldError(field, 'This field is required');
            isValid = false;
        }
    });

    return isValid;
}

function showFieldError(field, message) {
    field.classList.add('is-invalid');

    const errorDiv = document.createElement('div');
    errorDiv.className = 'invalid-feedback';
    errorDiv.textContent = message;

    field.parentNode.appendChild(errorDiv);
}

function initializeBulkActions() {
    const selectAllCheckbox = document.getElementById('selectAllBooks');
    const bookCheckboxes = document.querySelectorAll('.book-checkbox');

    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener('change', function() {
            bookCheckboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
            updateBulkActions();
        });
    }

    bookCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateBulkActions);
    });
}

function updateBulkActions() {
    const selectedCount = document.querySelectorAll('.book-checkbox:checked').length;
    const bulkActions = document.getElementById('bulkActions');

    if (bulkActions) {
        if (selectedCount > 0) {
            bulkActions.style.display = 'block';
            document.getElementById('selectedCount').textContent = selectedCount;
        } else {
            bulkActions.style.display = 'none';
        }
    }
}

function performBulkAction(action) {
    const selectedIds = Array.from(document.querySelectorAll('.book-checkbox:checked'))
        .map(checkbox => checkbox.value);

    if (selectedIds.length === 0) {
        showNotification('Please select at least one book', 'warning');
        return;
    }

    let confirmMessage = '';
    let endpoint = '';

    switch (action) {
        case 'delete':
            confirmMessage = `Are you sure you want to delete ${selectedIds.length} selected book(s)?`;
            endpoint = '/admin/books/bulk-delete';
            break;
        case 'activate':
            confirmMessage = `Are you sure you want to activate ${selectedIds.length} selected book(s)?`;
            endpoint = '/admin/books/bulk-activate';
            break;
        case 'deactivate':
            confirmMessage = `Are you sure you want to deactivate ${selectedIds.length} selected book(s)?`;
            endpoint = '/admin/books/bulk-deactivate';
            break;
    }

    if (!confirm(confirmMessage)) {
        return;
    }

    // Perform bulk action via AJAX
    fetch(endpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ bookIds: selectedIds })
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification(data.message, 'success');
                // Reload the page or update the table
                setTimeout(() => location.reload(), 1000);
            } else {
                showNotification(data.message, 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showNotification('An error occurred', 'error');
        });
}

function updateBookStats() {
    const totalBooks = document.querySelectorAll('.books-table tbody tr').length;
    const availableBooks = document.querySelectorAll('.books-table tbody tr .badge.bg-success').length;
    const unavailableBooks = document.querySelectorAll('.books-table tbody tr .badge.bg-danger').length;

    // Update stats display if exists
    const statsElement = document.getElementById('bookStats');
    if (statsElement) {
        statsElement.innerHTML = `
            Total: ${totalBooks} | 
            Available: ${availableBooks} | 
            Unavailable: ${unavailableBooks}
        `;
    }
}

// Export books to CSV
function exportBooks() {
    const table = document.querySelector('.books-table');
    if (!table) return;

    const filename = `books_export_${new Date().toISOString().split('T')[0]}.csv`;
    exportTableToCSV(table.id, filename);
}

// Quick add book function
function quickAddBook() {
    const modal = new bootstrap.Modal(document.getElementById('addBookModal'));
    modal.show();
}

// Book availability toggle
function toggleBookAvailability(bookId, currentStatus) {
    const newStatus = !currentStatus;
    const confirmMessage = newStatus ?
        'Are you sure you want to make this book available?' :
        'Are you sure you want to make this book unavailable?';

    if (!confirm(confirmMessage)) {
        return;
    }

    fetch(`/admin/books/${bookId}/availability`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ available: newStatus })
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showNotification('Book availability updated successfully', 'success');
                setTimeout(() => location.reload(), 1000);
            } else {
                showNotification(data.message, 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showNotification('An error occurred', 'error');
        });
}