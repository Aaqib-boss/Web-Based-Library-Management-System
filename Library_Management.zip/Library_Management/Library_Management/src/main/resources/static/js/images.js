// Image handling and lazy loading
document.addEventListener('DOMContentLoaded', function() {
    initializeImageHandling();
    setupLazyLoading();
});

function initializeImageHandling() {
    // Handle broken images
    const images = document.querySelectorAll('img');
    images.forEach(img => {
        img.addEventListener('error', function() {
            handleBrokenImage(this);
        });
    });

    // Add loading states to images
    images.forEach(img => {
        if (!img.complete) {
            img.style.opacity = '0';
            img.addEventListener('load', function() {
                this.style.transition = 'opacity 0.3s ease';
                this.style.opacity = '1';
            });
        }
    });
}

function handleBrokenImage(img) {
    const parent = img.parentElement;

    // If it's a book cover
    if (img.classList.contains('book-cover') || img.src.includes('book')) {
        const title = img.alt || 'Book';
        const placeholder = createBookCoverPlaceholder(title);
        parent.replaceChild(placeholder, img);
    }
    // If it's a user avatar
    else if (img.classList.contains('user-avatar')) {
        const userName = img.alt || 'User';
        const placeholder = createAvatarPlaceholder(userName);
        parent.replaceChild(placeholder, img);
    }
    // For other images
    else {
        img.style.display = 'none';
        const fallback = document.createElement('div');
        fallback.className = 'image-placeholder';
        fallback.innerHTML = `<i class="fas fa-image"></i>`;
        parent.appendChild(fallback);
    }
}

function createBookCoverPlaceholder(title) {
    const placeholder = document.createElement('div');
    placeholder.className = 'book-cover-placeholder';
    if (title.length > 1) {
        placeholder.textContent = title.substring(0, 1).toUpperCase();
    } else {
        placeholder.textContent = 'B';
    }
    placeholder.title = title;
    return placeholder;
}

function createAvatarPlaceholder(userName) {
    const placeholder = document.createElement('div');
    placeholder.className = 'avatar-placeholder';
    if (userName.length > 1) {
        placeholder.textContent = userName.substring(0, 1).toUpperCase();
    } else {
        placeholder.textContent = 'U';
    }
    placeholder.title = userName;
    return placeholder;
}

function setupLazyLoading() {
    if ('IntersectionObserver' in window) {
        const lazyImageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const lazyImage = entry.target;
                    lazyImage.src = lazyImage.dataset.src;
                    lazyImage.classList.remove('lazy');
                    lazyImageObserver.unobserve(lazyImage);
                }
            });
        });

        const lazyImages = document.querySelectorAll('img.lazy');
        lazyImages.forEach(lazyImage => {
            lazyImageObserver.observe(lazyImage);
        });
    }
}

// Image upload functionality (for future features)
function handleImageUpload(input, previewId) {
    const file = input.files[0];
    if (file) {
        const reader = new FileReader();

        reader.onload = function(e) {
            const preview = document.getElementById(previewId);
            preview.src = e.target.result;
            preview.style.display = 'block';
        }

        reader.readAsDataURL(file);
    }
}

// Image compression for uploads
function compressImage(file, maxWidth = 800, maxHeight = 600, quality = 0.8) {
    return new Promise((resolve) => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const img = new Image();

        img.onload = function() {
            let width = img.width;
            let height = img.height;

            // Calculate new dimensions
            if (width > height) {
                if (width > maxWidth) {
                    height *= maxWidth / width;
                    width = maxWidth;
                }
            } else {
                if (height > maxHeight) {
                    width *= maxHeight / height;
                    height = maxHeight;
                }
            }

            canvas.width = width;
            canvas.height = height;

            ctx.drawImage(img, 0, 0, width, height);
            canvas.toBlob(resolve, 'image/jpeg', quality);
        };

        img.src = URL.createObjectURL(file);
    });
}