package com.group176.SE_PROJECT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories("com.group176.SE_PROJECT.repository")
@EntityScan("com.group176.SE_PROJECT.model")
public class LibraryManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(LibraryManagementApplication.class, args);


        System.out.println("=========================================");
        System.out.println("🚀 Library Management System Started!");
        System.out.println("📍 URL: http://localhost:8080");
        System.out.println("👤 Default Admin: admin / admin123");
        System.out.println("=========================================");
    }
}