package com.group176.SE_PROJECT.config;

import com.group176.SE_PROJECT.model.User;
import com.group176.SE_PROJECT.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserService userService;

    @Override
    public void run(String... args) throws Exception {
        // Create default admin user
        if (userService.findByEmail("admin@gmail.com").isEmpty()) {
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword("admin123");
            admin.setEmail("admin@gmail.com");
            admin.setFirstName("Admin");
            admin.setLastName("User");
            admin.setPhone("1234567890");
            admin.setAddress("Library Administration");
            admin.setRole("ADMIN");
            admin.setIsActive(true);
            userService.saveUser(admin);
            System.out.println("✅ Default admin user created!");
            System.out.println("📧 Email: admin@gmail.com");
            System.out.println("🔑 Password: admin123");
        }
    }
}