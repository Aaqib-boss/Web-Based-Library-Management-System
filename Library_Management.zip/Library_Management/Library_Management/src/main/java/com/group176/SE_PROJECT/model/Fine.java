package com.group176.SE_PROJECT.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.time.LocalDateTime;

@Entity
@Table(name = "fines")
public class Fine {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "User is required")
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "borrow_record_id")
    private BorrowRecord borrowRecord;

    @NotNull(message = "Amount is required")
    @Positive(message = "Amount must be positive")
    @Column(nullable = false)
    private Double amount;

    @Column(name = "paid_amount")
    private Double paidAmount = 0.0;

    @Column(name = "reason")
    private String reason;

    @Column(name = "status")
    private String status = "PENDING"; // PENDING, PAID, PARTIALLY_PAID

    @Column(name = "is_paid")
    private Boolean isPaid = false;

    @Column(name = "created_date")
    private LocalDateTime createdDate = LocalDateTime.now();

    @Column(name = "paid_date")
    private LocalDateTime paidDate;

    @Column(name = "updated_date")
    private LocalDateTime updatedDate;

    // Constructors
    public Fine() {}

    public Fine(User user, Double amount, String reason) {
        this.user = user;
        this.amount = amount;
        this.reason = reason;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public BorrowRecord getBorrowRecord() { return borrowRecord; }
    public void setBorrowRecord(BorrowRecord borrowRecord) { this.borrowRecord = borrowRecord; }

    public Double getAmount() { return amount; }
    public void setAmount(Double amount) { this.amount = amount; }

    public Double getPaidAmount() { return paidAmount; }
    public void setPaidAmount(Double paidAmount) { this.paidAmount = paidAmount; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Boolean getIsPaid() { return isPaid; }
    public void setIsPaid(Boolean isPaid) { this.isPaid = isPaid; }

    public LocalDateTime getCreatedDate() { return createdDate; }
    public void setCreatedDate(LocalDateTime createdDate) { this.createdDate = createdDate; }

    public LocalDateTime getPaidDate() { return paidDate; }
    public void setPaidDate(LocalDateTime paidDate) { this.paidDate = paidDate; }

    public LocalDateTime getUpdatedDate() { return updatedDate; }
    public void setUpdatedDate(LocalDateTime updatedDate) { this.updatedDate = updatedDate; }

    // Helper methods
    public Double getRemainingAmount() {
        return amount - paidAmount;
    }

    public boolean isFullyPaid() {
        return paidAmount >= amount;
    }

    public void makePayment(Double paymentAmount) {
        this.paidAmount += paymentAmount;
        this.updatedDate = LocalDateTime.now();
        
        if (isFullyPaid()) {
            this.status = "PAID";
            this.isPaid = true;
            this.paidDate = LocalDateTime.now();
        } else {
            this.status = "PARTIALLY_PAID";
        }
    }
}