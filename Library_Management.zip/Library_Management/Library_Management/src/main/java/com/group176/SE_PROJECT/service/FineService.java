package com.group176.SE_PROJECT.service;

import com.group176.SE_PROJECT.model.Fine;
import com.group176.SE_PROJECT.model.User;  // ✅ IMPORT ADD பண்ணுங்க
import com.group176.SE_PROJECT.repository.FineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class FineService {

    @Autowired
    private FineRepository fineRepository;

    public List<Fine> getAllFines() {
        return fineRepository.findAll();
    }

    public List<Fine> getFinesByUser(User user) {
        return fineRepository.findByUser(user);
    }

    public List<Fine> getUnpaidFines() {
        return fineRepository.findByIsPaid(false);
    }

    public Fine saveFine(Fine fine) {
        return fineRepository.save(fine);
    }

    public void payFine(Long fineId) {
        Fine fine = fineRepository.findById(fineId).orElse(null);
        if (fine != null) {
            fine.setIsPaid(true);
            fine.setPaidDate(java.time.LocalDateTime.now());
            fineRepository.save(fine);
        }
    }
}