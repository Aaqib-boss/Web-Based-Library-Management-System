package com.group176.SE_PROJECT.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import jakarta.servlet.http.HttpSessionEvent; // Change to jakarta
import jakarta.servlet.http.HttpSessionListener; // Change to jakarta

@Configuration
public class SessionConfig implements WebMvcConfigurer {

    @Bean
    public HttpSessionListener httpSessionListener() {
        return new HttpSessionListener() {
            @Override
            public void sessionCreated(HttpSessionEvent se) {
                // Session timeout - 30 minutes
                se.getSession().setMaxInactiveInterval(30 * 60);
            }

            @Override
            public void sessionDestroyed(HttpSessionEvent se) {
                // Clean up session resources if needed
                System.out.println("Session destroyed: " + se.getSession().getId());
            }
        };
    }
}