package com.group176.SE_PROJECT.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "library")
public class ApplicationProperties {

    private int maxBorrowLimit = 5;
    private int borrowPeriodDays = 14;
    private double finePerDay = 10.0;
    private int lowStockThreshold = 5;

    // Getters and Setters
    public int getMaxBorrowLimit() {
        return maxBorrowLimit;
    }

    public void setMaxBorrowLimit(int maxBorrowLimit) {
        this.maxBorrowLimit = maxBorrowLimit;
    }

    public int getBorrowPeriodDays() {
        return borrowPeriodDays;
    }

    public void setBorrowPeriodDays(int borrowPeriodDays) {
        this.borrowPeriodDays = borrowPeriodDays;
    }

    public double getFinePerDay() {
        return finePerDay;
    }

    public void setFinePerDay(double finePerDay) {
        this.finePerDay = finePerDay;
    }

    public int getLowStockThreshold() {
        return lowStockThreshold;
    }

    public void setLowStockThreshold(int lowStockThreshold) {
        this.lowStockThreshold = lowStockThreshold;
    }
}