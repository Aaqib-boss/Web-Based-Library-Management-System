package com.group176.SE_PROJECT.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@Configuration
@EnableScheduling
public class SchedulerConfig {

    // Scheduled tasks are enabled globally
    // Individual scheduled methods are in respective services
}