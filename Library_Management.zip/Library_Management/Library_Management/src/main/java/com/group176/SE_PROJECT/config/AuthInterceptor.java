package com.group176.SE_PROJECT.config;

import jakarta.servlet.http.HttpServletRequest; // Change to jakarta
import jakarta.servlet.http.HttpServletResponse; // Change to jakarta
import jakarta.servlet.http.HttpSession; // Change to jakarta
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class AuthInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response,
                             Object handler) throws Exception {

        HttpSession session = request.getSession(false);
        String requestURI = request.getRequestURI();

        // Allow public paths
        if (requestURI.startsWith("/css/") ||
                requestURI.startsWith("/js/") ||
                requestURI.startsWith("/images/") ||
                requestURI.startsWith("/auth/") ||
                requestURI.equals("/") ||
                requestURI.equals("/login") ||
                requestURI.equals("/register")) {
            return true;
        }

        // Check if user is logged in
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("/auth/login");
            return false;
        }

        return true;
    }
}