package com.group176.SE_PROJECT.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/static/**")
                .addResourceLocations("classpath:/static/");

        registry.addResourceHandler("/css/**")
                .addResourceLocations("classpath:/static/css/");

        registry.addResourceHandler("/js/**")
                .addResourceLocations("classpath:/static/js/");

        registry.addResourceHandler("/images/**")
                .addResourceLocations("classpath:/static/images/");
    }

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        // Redirect root to login
        registry.addViewController("/").setViewName("redirect:/auth/login");

        // Custom error pages
        registry.addViewController("/error").setViewName("error/error");
        registry.addViewController("/access-denied").setViewName("error/access-denied");
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // Add authentication interceptor
        registry.addInterceptor(new AuthInterceptor())
                .addPathPatterns("/admin/**", "/member/**")
                .excludePathPatterns("/auth/**", "/static/**", "/error");
    }
}