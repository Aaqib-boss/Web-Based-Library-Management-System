package com.group176.SE_PROJECT.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

    @GetMapping("/test")
    public String test() {
        return "✅ Spring Boot Basic Setup Working!";
    }

    @GetMapping("/testHome")  // "/" path avoid pannitu, unique-a use pannirukkom
    public String home() {
        return "Welcome to Library Management System!";
    }
}
