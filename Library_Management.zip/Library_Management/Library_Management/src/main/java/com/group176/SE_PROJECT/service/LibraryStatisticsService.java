package com.group176.SE_PROJECT.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.HashMap;

@Service
public class LibraryStatisticsService {

    @Autowired
    private BookService bookService;

    @Autowired
    private UserService userService;

    public Map<String, Object> getLibraryStatistics() {
        Map<String, Object> stats = new HashMap<>();

        stats.put("totalBooks", bookService.getAllBooks().size());
        stats.put("totalUsers", userService.getAllUsers().size());

        return stats;
    }
}