package com.group176.SE_PROJECT.repository;

import com.group176.SE_PROJECT.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {

    // Find book by ISBN
    Optional<Book> findByIsbn(String isbn);

    // Find available books (books with available copies > 0)
    @Query("SELECT b FROM Book b WHERE b.availableCopies > 0")
    List<Book> findAvailableBooks();

    // Find books by genre
    List<Book> findByGenre(String genre);

    // Find books by author (case insensitive contains)
    List<Book> findByAuthorContainingIgnoreCase(String author);

    // Find books by title (case insensitive contains)
    List<Book> findByTitleContainingIgnoreCase(String title);

    // Search books by multiple fields
    @Query("SELECT b FROM Book b WHERE " +
            "LOWER(b.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(b.author) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(b.genre) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(b.isbn) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Book> searchBooks(@Param("keyword") String keyword);

    // Find books with low stock (available copies less than 5)
    @Query("SELECT b FROM Book b WHERE b.availableCopies < 5 AND b.availableCopies > 0")
    List<Book> findBooksWithLowStock();

    // Find out-of-stock books
    @Query("SELECT b FROM Book b WHERE b.availableCopies = 0")
    List<Book> findOutOfStockBooks();

    // Count books by genre
    @Query("SELECT b.genre, COUNT(b) FROM Book b GROUP BY b.genre")
    List<Object[]> countBooksByGenre();

    // Find top borrowed books
    @Query("SELECT b, COUNT(br) as borrowCount FROM Book b JOIN BorrowRecord br ON b.id = br.book.id GROUP BY b ORDER BY borrowCount DESC")
    List<Object[]> findTopBorrowedBooks();

    // Find books borrowed by a specific user
    @Query("SELECT DISTINCT b FROM Book b JOIN BorrowRecord br ON b.id = br.book.id WHERE br.user.id = :userId")
    List<Book> findBooksBorrowedByUser(@Param("userId") Long userId);

    // Check if ISBN exists (excluding a specific book for updates)
    @Query("SELECT COUNT(b) > 0 FROM Book b WHERE b.isbn = :isbn AND b.id != :excludeId")
    boolean existsByIsbnAndIdNot(@Param("isbn") String isbn, @Param("excludeId") Long excludeId);

    // Find books added in the last 30 days
    @Query("SELECT b FROM Book b WHERE b.createdDate >= :thirtyDaysAgo")
    List<Book> findRecentBooks(@Param("thirtyDaysAgo") LocalDateTime thirtyDaysAgo);
}