package com.group176.SE_PROJECT.service;

import com.group176.SE_PROJECT.model.BorrowRecord;
import com.group176.SE_PROJECT.model.Book;
import com.group176.SE_PROJECT.model.User;
import com.group176.SE_PROJECT.repository.BorrowRecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class BorrowService {

    @Autowired
    private BorrowRecordRepository borrowRecordRepository;

    @Autowired
    private BookService bookService;

    @Autowired
    private UserService userService;

    public BorrowRecord borrowBook(Long userId, Long bookId) {
        Optional<User> userOpt = userService.getUserById(userId);
        Optional<Book> bookOpt = bookService.getBookById(bookId);

        if (userOpt.isPresent() && bookOpt.isPresent() && bookService.isBookAvailable(bookId)) {
            Book book = bookOpt.get();

            BorrowRecord borrowRecord = new BorrowRecord();
            borrowRecord.setUser(userOpt.get());
            borrowRecord.setBook(book);
            borrowRecord.setBorrowDate(LocalDateTime.now());
            borrowRecord.setDueDate(LocalDateTime.now().plusDays(14)); // 2 weeks
            borrowRecord.setStatus("BORROWED");

            // Decrease available copies
            bookService.decreaseAvailableCopies(bookId);

            return borrowRecordRepository.save(borrowRecord);
        }
        return null;
    }

    public boolean returnBook(Long borrowRecordId) {
        Optional<BorrowRecord> recordOpt = borrowRecordRepository.findById(borrowRecordId);
        if (recordOpt.isPresent()) {
            BorrowRecord record = recordOpt.get();
            record.setReturnDate(LocalDateTime.now());
            record.setStatus("RETURNED");

            // Increase available copies
            bookService.increaseAvailableCopies(record.getBook().getId());

            borrowRecordRepository.save(record);
            return true;
        }
        return false;
    }

    public List<BorrowRecord> getBorrowedBooksByUser(Long userId) {
        Optional<User> userOpt = userService.getUserById(userId);
        return userOpt.map(borrowRecordRepository::findByUser).orElse(List.of());
    }

    public List<BorrowRecord> getOverdueBooks() {
        return borrowRecordRepository.findByStatus("OVERDUE");
    }

    public List<BorrowRecord> getActiveBorrows() {
        return borrowRecordRepository.findByReturnDateIsNull();
    }
}