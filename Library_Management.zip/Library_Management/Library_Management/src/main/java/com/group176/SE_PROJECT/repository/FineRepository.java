package com.group176.SE_PROJECT.repository;

import com.group176.SE_PROJECT.model.User;
import com.group176.SE_PROJECT.model.Fine;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FineRepository extends JpaRepository<Fine, Long> {

    // Simple methods - Status related ah illama
    List<Fine> findByUser(User user);
    List<Fine> findByIsPaid(Boolean isPaid);
    List<Fine> findByAmountGreaterThan(Double amount);
}