package com.group176.SE_PROJECT.controller;

import com.group176.SE_PROJECT.model.User;
import com.group176.SE_PROJECT.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpSession;
import java.time.LocalDateTime;
import java.util.Optional;

@Controller
public class AuthController {

    @Autowired
    private UserService userService;

    @GetMapping("/auth/login")
    public String loginPage() {
        return "auth/login";
    }

    @PostMapping("/auth/login")
    public String login(@RequestParam String email,
                        @RequestParam String password,
                        @RequestParam String role,
                        HttpSession session,
                        Model model) {

        // Validate email format
        if (!email.endsWith("@gmail.com")) {
            model.addAttribute("error", "Email must end with @gmail.com");
            return "auth/login";
        }

        // Validate password length
        if (password.length() < 8) {
            model.addAttribute("error", "Password must be at least 8 characters long");
            return "auth/login";
        }

        // Find user by email
        Optional<User> userOptional = userService.findByEmail(email);

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            
            // Check password and role
            if (user.getPassword().equals(password) && user.getRole().equals(role)) {
                // Update last login
                user.setLastLogin(LocalDateTime.now());
                userService.saveUser(user);
                
                session.setAttribute("user", user);
                
                // Redirect based on role
                if ("ADMIN".equals(role)) {
                    return "redirect:/admin/dashboard";
                } else {
                    return "redirect:/member/dashboard";
                }
            } else {
                model.addAttribute("error", "Invalid email, password, or role");
                return "auth/login";
            }
        } else {
            model.addAttribute("error", "Invalid email, password, or role");
            return "auth/login";
        }
    }

    @GetMapping("/auth/register")
    public String registerPage() {
        return "auth/register";
    }

    @PostMapping("/auth/register")
    public String register(@ModelAttribute User user, Model model) {
        // Validate email format
        if (!user.getEmail().endsWith("@gmail.com")) {
            model.addAttribute("error", "Email must end with @gmail.com");
            return "auth/register";
        }

        // Validate password length
        if (user.getPassword().length() < 8) {
            model.addAttribute("error", "Password must be at least 8 characters long");
            return "auth/register";
        }

        // Validate phone number
        if (user.getPhone() == null || user.getPhone().length() != 10 || !user.getPhone().matches("\\d{10}")) {
            model.addAttribute("error", "Phone number must be exactly 10 digits");
            return "auth/register";
        }

        // Check if email already exists
        if (userService.existsByEmail(user.getEmail())) {
            model.addAttribute("error", "Email already exists");
            return "auth/register";
        }

        // Check if username already exists
        if (userService.existsByUsername(user.getUsername())) {
            model.addAttribute("error", "Username already exists");
            return "auth/register";
        }

        // Set default values
        user.setRole("MEMBER");
        user.setIsActive(true);
        user.setCreatedDate(LocalDateTime.now());

        // Save user
        userService.saveUser(user);
        model.addAttribute("success", "Registration successful! Please login with your email and password.");
        return "auth/login";
    }

    @GetMapping("/auth/forgot-password")
    public String forgotPasswordPage() {
        return "auth/forgot-password";
    }

    @PostMapping("/auth/forgot-password")
    public String forgotPassword(@RequestParam String email, Model model) {
        Optional<User> userOptional = userService.findByEmail(email);
        
        if (userOptional.isPresent()) {
            // In a real application, you would send an email with reset link
            // For now, we'll just show a success message
            model.addAttribute("success", "Password reset instructions have been sent to your email address.");
        } else {
            model.addAttribute("error", "No account found with this email address.");
        }
        
        return "auth/forgot-password";
    }

    @GetMapping("/auth/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/auth/login";
    }
}