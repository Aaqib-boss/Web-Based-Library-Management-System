package com.group176.SE_PROJECT.repository;

import com.group176.SE_PROJECT.model.User;
import com.group176.SE_PROJECT.model.BorrowRecord;
import com.group176.SE_PROJECT.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface BorrowRecordRepository extends JpaRepository<BorrowRecord, Long> {

    // Simple methods - Status related ah illama
    List<BorrowRecord> findByUser(User user);
    List<BorrowRecord> findByBook(Book book);
    List<BorrowRecord> findByStatus(String status); // String type use pannunga
    List<BorrowRecord> findByReturnDateIsNull();
    Optional<BorrowRecord> findByUserIdAndBookIdAndReturnDateIsNull(Long userId, Long bookId);
}