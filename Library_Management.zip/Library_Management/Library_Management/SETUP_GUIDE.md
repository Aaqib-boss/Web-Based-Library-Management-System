# Library Management System - Setup Guide

This guide will help you set up and run the Library Management System on your local machine.

## 📋 Prerequisites Checklist

Before starting, ensure you have the following installed:

- [ ] **Java 17** or higher
- [ ] **Microsoft SQL Server** (2019 or later)
- [ ] **SQL Server Management Studio** (optional but recommended)
- [ ] **Git** (if cloning from repository)

## 🔧 Step-by-Step Setup

### Step 1: Verify Java Installation

Open Command Prompt or PowerShell and run:
```bash
java -version
```

You should see output similar to:
```
openjdk version "17.0.x" 2024-xx-xx
OpenJDK Runtime Environment Temurin-17.0.x+x (build 17.0.x+x)
OpenJDK 64-Bit Server VM Temurin-17.0.x+x (build 17.0.x+x, mixed mode, sharing)
```

If Java is not installed or the version is below 17, download and install Java 17 from [Adoptium](https://adoptium.net/).

### Step 2: Set Up SQL Server Database

#### Option A: Using SQL Server Management Studio (Recommended)

1. **Open SQL Server Management Studio**
2. **Connect to your SQL Server instance** (usually `localhost` or `.\SQLEXPRESS`)
3. **Open the database setup script**:
   - File → Open → File
   - Navigate to the project folder
   - Select `database_setup.sql`
4. **Execute the script**:
   - Click the "Execute" button or press F5
   - Wait for the script to complete
   - Verify that the `LibraryDB` database and tables are created

#### Option B: Using Command Line

1. **Open Command Prompt as Administrator**
2. **Navigate to the project directory**:
   ```bash
   cd C:\path\to\Library_Management
   ```
3. **Run the database setup script**:
   ```bash
   sqlcmd -S localhost -i database_setup.sql
   ```

### Step 3: Configure Database Connection

1. **Open the application properties file**:
   - Navigate to `src/main/resources/application.properties`
2. **Update database credentials** (if different from defaults):
   ```properties
   spring.datasource.url=jdbc:sqlserver://localhost:1433;databaseName=LibraryDB;encrypt=true;trustServerCertificate=true
   spring.datasource.username=your_username
   spring.datasource.password=your_password
   ```

### Step 4: Run the Application

#### Option A: Using the Batch Script (Easiest)

1. **Double-click `run.bat`** in the project folder
2. **Follow the prompts** in the command window
3. **Wait for the application to start**

#### Option B: Using Command Line

1. **Open Command Prompt or PowerShell**
2. **Navigate to the project directory**:
   ```bash
   cd C:\path\to\Library_Management
   ```
3. **Run the application**:
   ```bash
   .\mvnw.cmd spring-boot:run
   ```

#### Option C: Using IDE

1. **Import the project** into your IDE (IntelliJ IDEA, Eclipse, VS Code)
2. **Wait for Maven to download dependencies**
3. **Run the `LibraryManagementApplication.java` class**

### Step 5: Access the Application

1. **Open your web browser**
2. **Navigate to**: http://localhost:8080
3. **Login with default credentials**:
   - **Admin**: username: `admin`, password: `admin123`
   - **User**: username: `user1`, password: `user123`

## 🎯 Verification Steps

After setup, verify everything is working:

### 1. Check Application Startup
Look for these messages in the console:
```
🚀 Library Management System Started!
📍 URL: http://localhost:8080
👤 Default Admin: admin / admin123
```

### 2. Test Database Connection
- Login as admin
- Navigate to the books section
- Verify you can see the sample books

### 3. Test User Authentication
- Try logging in with both admin and user accounts
- Verify different access levels

## 🐛 Troubleshooting

### Common Issues and Solutions

#### Issue: "Port 8080 already in use"
**Solution**: 
- Change the port in `application.properties`:
  ```properties
  server.port=8081
  ```
- Or stop the process using port 8080

#### Issue: "Database connection failed"
**Solutions**:
- Verify SQL Server is running
- Check database credentials
- Ensure `LibraryDB` database exists
- Verify SQL Server is configured to accept connections

#### Issue: "Java version not supported"
**Solution**:
- Install Java 17 or higher
- Update JAVA_HOME environment variable
- Restart Command Prompt/PowerShell

#### Issue: "Maven command not found"
**Solution**:
- Use the Maven wrapper: `.\mvnw.cmd` instead of `mvn`
- Or install Maven and add it to PATH

#### Issue: "Compilation errors"
**Solutions**:
- Run `.\mvnw.cmd clean compile`
- Check Java version compatibility
- Verify all dependencies are downloaded

### Getting Help

If you encounter issues not covered here:

1. **Check the console output** for error messages
2. **Verify all prerequisites** are installed correctly
3. **Check the README.md** for additional information
4. **Create an issue** in the project repository

## 📊 Default Data

The application comes with sample data:

### Users
- **Admin**: admin / admin123
- **Regular User**: user1 / user123

### Sample Books
- The Great Gatsby (F. Scott Fitzgerald)
- To Kill a Mockingbird (Harper Lee)
- 1984 (George Orwell)
- Pride and Prejudice (Jane Austen)
- The Catcher in the Rye (J.D. Salinger)

## 🎉 Success!

If you've followed all steps and can access the application at http://localhost:8080, congratulations! Your Library Management System is now running successfully.

You can now:
- Add new books
- Create user accounts
- Test the borrowing system
- Explore all features

---

**Need help?** Check the main README.md file or contact the development team.

